/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */
import java.util.Random;
import java.lang.Math;

public class PercolationStats {
    // perform trials independent experiments on an n-by-n grid
    int[] switchesTaken;
    int numTrials;
    static final double STANDARD_DEVS = 1.96;
    //int gridSize;
    public PercolationStats(int n, int trials) {
        switchesTaken = new int[trials];
        numTrials = n;
        for (int i = 0; i < trials; i++) {
            switchesTaken[i] = oneTrial(n);
        }
    }

    private int oneTrial(int n) {
        Percolation percolation = new Percolation(n);
        Random rand = new Random();
        boolean isOpen = false;
        boolean hasPercolated = false;
        int row = 1;
        int col = 1;
        do {
             do {
                col = rand.nextInt(n) + 1;
                row = rand.nextInt(n) + 1;
                isOpen = percolation.isOpen(row, col);
            } while (isOpen);
            percolation.open(row, col);
            hasPercolated = percolation.percolates();
          } while (!hasPercolated);
          return percolation.numberOfOpenSites();
        }
    // sample mean of percolation threshold
    public double mean() {
        double result = 0.0;
        for (int numOpen : switchesTaken) {
            result += numOpen/(double) numTrials;
        }
        return result;
    }
    // sample standard deviation of percolation threshold
    public double stddev() {
        double result = 0.0;
        for (int numOpen : switchesTaken) {
            result += Math.pow(mean() - numOpen, 2);
        }
        return Math.pow(result/((double) numTrials - 1), 0.5);
    }
    // low  endpoint of 95% confidence interval
    public double confidenceLo() {
        return mean() - STANDARD_DEVS * stddev() / Math.pow((double) numTrials, 0.5);
    }
    public double confidenceHi() {
        return mean() + STANDARD_DEVS * stddev() / Math.pow((double) numTrials, 0.5);
    }                 // high endpoint of 95% confidence interval

    public static void main(String[] args) {

        // Parse the string argument into an integer value.
        int n = Integer.parseInt(args[0]);
        int trials = Integer.parseInt(args[1]);


        PercolationStats percolationStats = new PercolationStats(n, trials);
        System.out.println("mean                    = " + percolationStats.mean());
        System.out.println("std                     = " + percolationStats.stddev());
        System.out.println("95% confidence interval = [" + percolationStats.confidenceLo() + "," + percolationStats.confidenceHi() + "]");

    }
}
